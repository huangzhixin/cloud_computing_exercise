#!/bin/bash

export CLASSPATH=/var/lib/jetty/webapps/hello_war_exploded/WEB-INF/classes/jaxr-impl-mwcc.jar:/var/lib/jetty/webapps/hello_war_exploded/WEB-INF/classes/jaxr-api.jar:./
