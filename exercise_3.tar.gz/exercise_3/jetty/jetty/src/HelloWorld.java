// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import mw.pathclient.JAXBException_Exception;
import mw.pathclient.MWNoSuchKeyException_Exception;

// Extend HttpServlet class
@WebServlet("/MyServlet")
public class HelloWorld extends HttpServlet {

    private String pathstr;

    public void init() throws ServletException
    {
        // Do required initialization
        pathstr = "Hello World!";
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException
    {
    	String id1 =request.getParameter("id1");
    	String id2 =request.getParameter("id2");
    	System.out.println(id1+" "+id2);
    	MWClient client = new MWClient();
    	try {
			pathstr = client.calculatePathForServerlet(id1, id2);
			
		} catch (JAXBException_Exception | MWNoSuchKeyException_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set response content type
        response.setContentType("text/html;charset=utf-8");

        // Actual logic goes here.
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        out.println("<HTML>");
        out.println("  <HEAD><TITLE>display survey information</TITLE></HEAD>");
        out.println("  <BODY>");
        out.println("<h1>" + pathstr + "</h1>");
        out.println("  </BODY>");
        out.println("</HTML>");
        out.flush();
        out.close();
    }

    public void destroy()
    {
        // do nothing.
    }
}
