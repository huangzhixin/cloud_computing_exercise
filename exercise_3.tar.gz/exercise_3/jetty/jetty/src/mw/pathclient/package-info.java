@javax.xml.bind.annotation.XmlSchema(namespace = "http://path.mw/")
package mw.pathclient;
