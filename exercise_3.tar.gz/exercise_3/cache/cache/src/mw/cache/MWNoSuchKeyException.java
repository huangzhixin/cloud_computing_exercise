package mw.cache;

import javax.xml.bind.JAXBException;



public class MWNoSuchKeyException extends Exception {
	 
	public MWNoSuchKeyException()  {
		System.out.println("NO Such Key !!!!!!! call MWFacebookService to calculatePath!!! ");
   }
}
