#!/bin/bash

cd /var/lib/cache/bin

java -cp ./:../jaxr-api.jar:../jarx-impl-mwcc.jar mw/cache/MWCache
